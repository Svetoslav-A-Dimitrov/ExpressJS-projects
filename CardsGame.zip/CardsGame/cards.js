$(() =>  {
  let ranks = ["ace", "2", "3", "4", "5", "6", "7", "8", "9", "10",
    "jack", "queen", "king"];
  let suits = ["clubs", "diamonds", "hearts", "spades"];
  let deck = []

  ranks.forEach(r => suits.forEach(s => deck.push({suite: s, rank: r}))) // populate deck

  function getRandomCard() {
    return deck[Math.floor(Math.random() * 52)];  // math.random is predictable
  }

  $('.card').each( (i, v) =>{
    'use strict'
    let card = getRandomCard();
    let cardImg = new Image();

    let cardInfo = card.rank + '_of_' + card.suite + '.png'
    cardImg.src = "./cards-images/" + cardInfo

    $(v).html(cardImg)
  })
  $('#hit').click(()=> {
    'use strict'
    $('.secondory').each( (i, v) =>{
      'use strict'
      let card = getRandomCard()
      let cardImg = new Image();

      let cardInfo = card.rank + '_of_' + card.suite + '.png'
      cardImg.src = "./cards-images/" + cardInfo

      $(v).html(cardImg)

    })
  })

  $('.secondory').click((e) =>{
    let back = "./cards-images/" + 'back.jpg';

    turnCSS($(e.target),back )
  })

  function turnCSS(elem, src) {
    $(elem)
      .addClass("flipping")
      .bind("transitionend webkittransitionend", function () { //should add more prefixes
        this.src = src;
        $(this)
          .unbind("transitionend webkittransitionend")
          .removeClass("flipping")
      })
  }

})